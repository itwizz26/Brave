=== Brave Digital Theme ===

This theme is a child them adapted from the twentynineteen default theme.

Ensure that you activate this theme when Earthquake Catalog API plugin is active for it to work!

== Installation ==

Clone repo into the themes directory and run the "composer i" and "npm install" commands
to add the required composer package dependancies and node libraries.

== What's next ==

Activate the Brave Digital theme and start blogging!

== Changelog ==

= 5.7 =
*Release Date - 09 April 2021*

* Initial version release